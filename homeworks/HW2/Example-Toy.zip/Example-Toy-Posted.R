# Toy example of the dynamic Tree Cut algorithms.
# Author: Peter Langfelder, Peter dot Langfelder at gmail dot com

# If necessary, modify the directory in the following statement to point to your working directory and
# execute the command. 

# setwd("C:/Documents and Settings/Work/TreeCut/Simulation");

source("NetworkFunctions-TreeCut-Simulation.R");

library(dynamicTreeCut);
library(moduleColor);

data = c(1,2,3,4,5, 7,9,10,11,12,  19,24,28,32,38, 54);
dim(data) = c(1, length(data));

dissim = dist(t(data));

dendro = hclust(dissim, method = "average");

DetectedColors = NULL;

DetectedColors = cbind(DetectedColors,
                    labels2colors(cutreeDynamic(dendro = dendro,
                                        cutHeight = NULL, minClusterSize = 3,
                                        method = "tree", deepSplit = TRUE)));
DetectedColors = cbind(DetectedColors,
                    labels2colors(cutreeDynamic(dendro, cutHeight = NULL,
                          minClusterSize = 3,
                          method = "hybrid", deepSplit = 3,
                          pamStage = TRUE,  distM = as.matrix(dissim), maxDistToLabel = 0,
                          verbose = 0)));

Methods = c("Dynamic Tree", "Dynamic Hybrid");

StandardCex = 1.7;
width = 9;
SizeWindow(width, 4);
layout(matrix(c(1,2), nrow = 2, ncol = 1), widths = 1, heights = c(0.8, 0.2));
par(cex = 1.4);
par(mar=c(0, 6.5, 2, 0.2));
plot(dendro, labels = data,
     main = "Toy example: clustering dendrogram and module colors", ylab = "Difference");
par(mar=c(0.2, 6.5, 0, 0.2));
hclustplotn(dendro,
            DetectedColors,
            RowLabels = Methods,
            main="");

#dev.copy2eps(file = "Example-Toy-Dendrogram.eps");
#dev2bitmap(file =  "Example-Toy-Dendrogram.pdf", width = width, type = "pdfwrite");
#dev2bitmap(file =  "Example-Toy-Dendrogram.png", width = width, type = "png16m", res = 72);


% tut1mle.m (Nov 2001)/MLE/JMP tutorial on MLE
clear;
global n t x;
opts=optimset('DerivativeCheck','off','Display','off','TolX',1e-6,'TolFun',1e-6,...
   'Diagnostics','off','MaxIter', 200, 'LargeScale','off');

n=100;% number of trials
t=[1 3 6 9 12 18];t=t';
y=[.94 .77 .40 .26 .24 .16];y=y';
x=n*y;

[am1,loglik1,exit1]=fmincon('power_mle',rand(2,1),[],[],[],[],zeros(2,1),100*ones(2,1),[],opts);
[am2,loglik2,exit2]=fmincon('expo_mle',rand(2,1),[],[],[],[],zeros(2,1),100*ones(2,1),[],opts);
yprd1=am1(1,1)*t.^(-am1(2,1));
r2(1,1)=1-sum((yprd1-y).^2)/sum((y-mean(y)).^2);
yprd2=am2(1,1)*exp(-am2(2,1)*t);
r2(2,1)=1-sum((yprd2-y).^2)/sum((y-mean(y)).^2);
loglik(1,1)=loglik1;loglik(2,1)=loglik2;
exit(1,1)=exit1;exit(2,1)=exit2;

format long;disp(num2str([am1 am2 r2],5));disp(num2str([loglik1 loglik2 exit1 exit2],5));
